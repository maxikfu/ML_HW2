from keras.datasets import cifar10
from keras.models import Sequential
from keras.layers import Dense, Dropout, Flatten
from keras.layers import Embedding
from keras.layers import LSTM, Conv2D,ConvLSTM2D, TimeDistributed, MaxPooling2D
from keras.datasets import imdb
from keras.preprocessing import sequence
import keras
import numpy as np


n_rows = 32 # cifar10 data input (img shape: 32*32)
time_steps = 32 # timesteps
n_hidden = 32 # hidden layer num of features
num_classes = 10 # MNIST total classes (0-9 digits)
(x_train, y_train), (x_test, y_test) = cifar10.load_data()
# but we have RGB 3 colors what we will need to onvert into 1 Y' = 0.299 R + 0.587 G + 0.114 B
x_train_grayscale = np.dot(x_train[...,:3], [0.299, 0.587, 0.114])
x_test_grayscale = np.dot(x_test[...,:3], [0.299, 0.587, 0.114])
# Convert class vectors to binary class matrices.
y_train = keras.utils.to_categorical(y_train, num_classes)
y_test = keras.utils.to_categorical(y_test, num_classes)

x_train_grayscale = [image.reshape((-1,time_steps,n_rows))for image in x_train_grayscale]
x_train = np.array(x_train_grayscale).reshape((-1, time_steps, n_rows))
x_test_grayscale = [image.reshape((-1,time_steps,n_rows))for image in x_test_grayscale]
x_test = np.array(x_test_grayscale).reshape((-1, time_steps, n_rows))

model = Sequential()

# define LSTM model
model.add(LSTM(n_hidden, input_shape=(time_steps, n_rows)))
model.add(Dense(num_classes, activation='softmax'))

model.compile(loss='categorical_crossentropy',
              optimizer='rmsprop',
              metrics=['accuracy'])

model.fit(x_train, y_train, batch_size=32, epochs=10)
score, acc = model.evaluate(x_test, y_test, batch_size=32)
print('Test loss = ', score)
print('Test accuracy = ', acc)
