from keras.datasets import cifar10
from keras.models import Sequential
from keras.layers import Dense, Dropout, Flatten
from keras.layers import Embedding
from keras.layers import LSTM, Conv2D,ConvLSTM2D, TimeDistributed, MaxPooling2D
from keras.datasets import imdb
from keras.preprocessing import sequence
import keras
import numpy as np



n_rows = 32 # cifar10 data input (img shape: 32*32)
time_steps = 32 # timesteps
n_hidden = 1024 # hidden layer num of features
num_classes = 10 # MNIST total classes (0-9 digits)
(x_train, y_train), (x_test, y_test) = cifar10.load_data()

# Convert class vectors to binary class matrices.
y_train = keras.utils.to_categorical(y_train, num_classes)
y_test = keras.utils.to_categorical(y_test, num_classes)

# x_train = [image.reshape((-1,time_steps,n_rows))for image in x_train]
# x_test = [image.reshape((-1,time_steps,n_rows))for image in x_test]

model = Sequential()
# define CNN model
model.add(Conv2D(1, (3,3), activation='relu', padding='same', input_shape=(32,32,3)))
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(TimeDistributed(Flatten()))
# define LSTM model
model.add(LSTM(250))
model.add(Dense(10, activation='softmax'))


model.compile(loss='categorical_crossentropy',
              optimizer='rmsprop',
              metrics=['accuracy'])

model.fit(x_train, y_train, batch_size=128, epochs=10)
score, acc = model.evaluate(x_test, y_test, batch_size=32)
print('Test loss = ', score)
print('Test accuracy = ', acc)
